// Initialise the package with data.
let cwidget = {
  data: [],
};
const colorStops = {
  // For multi data charts
  pinkPurple: [
    {
      offset: 0,
      color: "hsla(306, 66%, 65%, 1)", // color at 0%: Pink
    },
    {
      offset: 1,
      color: "hsla(311, 87%, 35%, 1)", // color at 100%: Purple
    },
  ],
  blueViolet: [
    {
      offset: 0,
      color: "hsla(241, 68%, 61%, 1)", // color at 0%: Blue
    },
    {
      offset: 1,
      color: "hsla(274, 68%, 61%, 1)", // color at 100%: Violet
    },
  ],
  cyanBlue: [
    {
      offset: 0,
      color: "hsla(158, 63%, 69%, 1)", // color at 0%: Cyan
    },
    {
      offset: 1,
      color: "hsla(205, 65%, 60%, 1)", // color at 100%: Blue
    },
  ],
  yellowGreen: [
    {
      offset: 0,
      color: "hsla(75, 61%, 64%, 1)", // color at 0%: Yellow
    },
    {
      offset: 1,
      color: "hsla(119, 47%, 50%, 1)", // color at 100%: Blue
    },
  ],
  redOrange: [
    {
      offset: 0,
      color: "hsla(0, 69%, 59%, 1)", // color at 0%: Red
    },
    {
      offset: 1,
      color: "hsla(32, 62%, 60%, 1)", // color at 100%: Orange
    },
  ],
  // For two element complimentary charts
  redShade: [
    {
      offset: 0,
      color: "hsla(345, 74%, 63%, 1)", // color at 0%: Pinkish Red
    },
    {
      offset: 1,
      color: "hsla(15, 73%, 64%, 1)", // color at 100%: Orange Shift
    },
  ],
  greenShade: [
    {
      offset: 0,
      color: "hsla(114, 64%, 61%, 1)", // color at 0%: Light Green
    },
    {
      offset: 1,
      color: "hsla(162, 54%, 46%, 1)", // color at 100%: Blueish green
    },
  ],
  brownShade: [
    {
      offset: 0,
      color: "hsla(20, 100%, 29%, 1)", // color at 0%: Light Green
    },
    {
      offset: 1,
      color: "hsla(40, 100%, 29%, 1)", // color at 100%: Blueish green
    },
  ],
  // Continuous gradient for meter.
  redYellowGreen: [
    {
      offset: 0,
      color: "hsla(11, 71%, 62%, 1)", // color at 0%: Light Green
    },
    {
      offset: 0.5,
      color: "hsla(59, 678%, 71%, 1)", // color at 0%: Light Green
    },
    {
      offset: 1,
      color: "hsla(112, 64%, 61%, 1)", // color at 100%: Blueish green
    },
  ],
  lightBlueViolet: [
    {
      offset: 0,
      color: "hsla(194, 80%, 61%, 1)", // color at 0%: Cyan
    },
    {
      offset: 1,
      color: "hsla(266, 68%, 65%, 1)", // color at 100%: Violet
    },
  ],
  red: [
    {
      offset: 0,
      color: "hsla(336.8, 73.2%, 55.9%, 1)", // color at 0%: Cyan
    },
    {
      offset: 1,
      color: "hsla(0, 52.4%, 53.9%, 1)", // color at 100%: Violet
    },
  ],
};
var colors = [
  { offset: 0, color: "rgba(0, 255, 255, 0.8)" }, // Start color
  { offset: 1, color: "rgba(0, 0, 255, 0.5)" }, // End color
];
// This function is used for interaction with a global object called 'cwidget', that will be created during packaging into CWP.
// Any function or code that need to be interacted with System Platform or API, need to be inside this.
(function (cwidget) {
  var chartDom = document.getElementById("chartId11");
  var myChart = echarts.init(chartDom);
  var option;

  option = {
    series: [
      {
        type: "gauge",
        startAngle: 180,
        endAngle: 0,
        center: ["50%", "80%"],
        radius: "100%",
        min: 0,
        max: 14,
        splitNumber: 8,
        axisLine: {
          lineStyle: {
            width: 4,
            color: [
              [0.4673, "#F76464"], // 0 to 6.5, red color
              [0.6071, " #63EF7A"], // 6.5 to 8.5, green color
              [1, "#F76464"], // 80-100% range, green color
            ],
          },
        },
        pointer: {
          icon: "path://M12.8,0.7l12,40.1H0.7L12.8,0.7z",
          length: "12%",
          width: 10,
          offsetCenter: [0, "-50%"],
          itemStyle: {
            color: "auto",
          },
        },
        axisTick: {
          length: 10,
          lineStyle: {
            color: "auto",
            width: 1,
          },
        },
        splitLine: {
          length: 14,
          lineStyle: {
            color: "auto",
            width: 4,
          },
        },
        axisLabel: {
          color: "white",
          fontSize: 12,
          distance: -40,
          rotate: "horizontal",
          formatter: function (value) {
            if (value === 0) {
              return "0";
            } else if (value === 7) {
              return "7";
            } else if (value === 14) {
              return "14";
            }
            return "";
          },
        },
        title: {
          color: "white",
          offsetCenter: [0, "15%"],
          fontSize: 12,
        },
        detail: {
          fontSize: 20,
          offsetCenter: [0, "-10%"],
          valueAnimation: true,

          color: "inherit",
        },
        data: [
          {
            value: 7.1,
            name: "pH",
          },
        ],
      },
    ],
  };

  option && myChart.setOption(option);
  var chartDom2 = document.getElementById("chartId12");
  var myChart2 = echarts.init(chartDom2);
  var option2;

  option2 = {
    series: [
      {
        type: "gauge",
        startAngle: 180,
        endAngle: 0,
        center: ["50%", "80%"],
        radius: "100%",
        min: 0,
        max: 10,
        splitNumber: 8,
        axisLine: {
          lineStyle: {
            width: 4,
            color: [
              [0.5, "#63EF7A"], // From 0 to 5, red color
              [0.7, "#FCDE68"], // From 5 to 7.5, yellow color
              [1, "#F76464"], // From 7.5 to 10, red color
              // Above 10, red color
            ],
          },
        },
        pointer: {
          icon: "path://M12.8,0.7l12,40.1H0.7L12.8,0.7z",
          length: "12%",
          width: 10,
          offsetCenter: [0, "-50%"],
          itemStyle: {
            color: "auto",
          },
        },
        axisTick: {
          length: 10,
          lineStyle: {
            color: "auto",
            width: 1,
          },
        },
        splitLine: {
          length: 14,
          lineStyle: {
            color: "auto",
            width: 4,
          },
        },
        axisLabel: {
          fontSize: 12,
          distance: -40,
          color: "white",
          rotate: "Horizontal",
          formatter: function (value) {
            if (value === 0) {
              return "0";
            } else if (value === 2.5) {
              return "2.5";
            } else if (value === 5) {
              return "5";
            } else if (value === 7.5) {
              return "7.5";
            } else if (value === 10) {
              return "10";
            }
            return "";
          },
        },
        title: {
          color: "white",
          offsetCenter: [0, "15%"],
          fontSize: 12,
        },
        detail: {
          fontSize: 20,
          offsetCenter: [0, "-10%"],
          valueAnimation: true,

          color: "inherit",
        },
        data: [
          {
            value: 0.5,
            name: "Turbidity\n(NTU)",
          },
        ],
      },
    ],
  };

  option2 && myChart2.setOption(option2);
  var chartDom3 = document.getElementById("chartId13");
  var myChart3 = echarts.init(chartDom3);
  var option3;
  option3 = {
    series: [
      {
        type: "gauge",
        startAngle: 180,
        endAngle: 0,
        center: ["50%", "80%"],
        radius: "100%",
        min: 0,
        max: 6,
        splitNumber: 8,
        axisLine: {
          lineStyle: {
            width: 4,
            color: [
              [0.1, "#F76464"], // From 0 to 1, red color
              [0.2, "#FCDE68"], // From 1 to 1.5, yellow color
              [0.5, "#63EF7A"], // From 1.5 to 3.5, green color
              [0.625, "#FCDE68"], // From 3.5 to 4, yellow color
              [1, "#F76464"], // From 4 to 6, red color
            ],
          },
        },
        pointer: {
          icon: "path://M12.8,0.7l12,40.1H0.7L12.8,0.7z",
          length: "12%",
          width: 10,
          offsetCenter: [0, "-50%"],
          itemStyle: {
            color: "auto",
          },
        },
        axisTick: {
          length: 10,
          lineStyle: {
            color: "auto",
            width: 1,
          },
        },
        splitLine: {
          length: 14,
          lineStyle: {
            color: "auto",
            width: 4,
          },
        },
        axisLabel: {
          fontSize: 12,
          distance: -40,
          color: "white",
          rotate: "Horizontal",
          formatter: function (value) {
            if (value === 0) {
              return "0";
            } else if (value === 1.5) {
              return "1.5";
            } else if (value === 3) {
              return "3";
            } else if (value === 4.5) {
              return "4.5";
            } else if (value === 6) {
              return "6";
            }
            return "";
          },
        },
        title: {
          color: "white",
          offsetCenter: [0, "15%"],
          fontSize: 12,
        },
        detail: {
          fontSize: 20,
          offsetCenter: [0, "-10%"],
          valueAnimation: true,

          color: "inherit",
        },
        data: [
          {
            value: 2.3,
            name: "Residual\nChlorine",
          },
        ],
      },
    ],
  };

  option3 && myChart3.setOption(option3);
  var chartDom4 = document.getElementById("progressChart");
  var myChart4 = echarts.init(chartDom4);

  var option4 = {
    color: ["hsla(194, 96%, 46%, 1)", "grey"],
    tooltip: {
      show: false,
    },
    legend: {
      show: false,
    },

    grid: {
      left: "3%",
      right: "4%",
      bottom: "20%",
      top: "20%",
    },
    xAxis: {
      type: "value",
      axisLabel: {
        show: false,
      },

      splitLine: {
        show: false,
      },
    },
    yAxis: {
      type: "category",
      axisLabel: {
        show: false,
      },
      axisLine: {
        show: false,
      },
      axisTick: {
        show: false,
      },
    },
    series: [
      {
        name: "Value 1",
        type: "bar",
        stack: "total",

        label: {
          show: false,
        },
        itemStyle: {
          barBorderRadius: [5, 0, 0, 5],
        },
        data: [98],
      },

      {
        name: "Value 2",
        type: "bar",
        stack: "total",
        label: {
          show: false,
        },
        itemStyle: {
          barBorderRadius: [0, 5, 5, 0],
        },
        data: [2],
      },
    ],
  };

  // Set chart options and data
  myChart4.setOption(option4);

  var myChart9 = echarts.init(document.getElementById("chartId9"));

  window.addEventListener("resize", myfunction);
  function myfunction() {
    myChart9.resize();
    myChart10.resize();
  }

  var option9 = {
    color: [
      {
        type: "linear",
        x: 0,
        y: 0,
        x2: 1,
        y2: 0,
        colorStops: colorStops.redOrange,
      },
      {
        type: "linear",
        x: 0,
        y: 0,
        x2: 1,
        y2: 0,
        colorStops: colorStops.greenShade,
      },
    ],
    grid: {
      top: 10,
      bottom: "20%",
      left: "20%",
      right: "5%",
    },

    legend: {
      bottom: 0,
      textStyle: {
        color: "white",
      },
      data: ["Demand", "Production", "2023",{
        name: "Prev.Year",
        icon: "rect",
        itemStyle: {
          color: "#4FC3F7", // Set the color to blue for the icon
        },
      }],
      icon: "rect",
      itemWidth: 14,
      itemHeight: 10,
    },
    xAxis: [
      {
        type: "category",
        axisTick: { show: false },
        data: ["Jan", "Feb", "Mar", "Apr"],
        axisLine: {
          show: false,
          lineStyle: {
            color: "white",
          },
        },
      },
    ],
    yAxis: [
      {
        type: "value",
        name: "Volume of Water (MLD)",
        nameLocation: "middle",
        nameGap: 40,
        splitLine: {
          show: false,
        },
        axisLine: {
          show: false,
          lineStyle: {
            color: "white",
          },
        },
      },
    ],
    series: [
      {
        name: "Demand",
        type: "bar",
        barGap: 0,
        emphasis: {
          focus: "series",
        },
        data: [86, 95, 104, 102],
        markPoint: {
          symbol: "line",
          symbolSize: [28, 50],
          itemStyle: {
            color: "#4FC3F7 ",
          },
          data: [
            { xAxis: 0, yAxis: 86 },
            { xAxis: 1, yAxis: 95 },
            { xAxis: 2, yAxis: 104 },
            { xAxis: 3, yAxis: 102 },
          ],
        },
        label: {
          // Adding labels for each bar
          show: true,
          position: "inside", // Adjust label position as needed
          formatter: function (params) {
            return params.value; // Display the value of each bar as label
          },
        },
      },
      {
        name: "Production",
        type: "bar",

        emphasis: {
          focus: "series",
        },
        data: [88, 88, 90, 90],
        markPoint: {
          symbol: "line",
          symbolSize: [28, 50],

          lineWidth: 5,
          radius: 10,
          itemStyle: {
            color: "#4FC3F7 ",
          },
          data: [
            { xAxis: 0, yAxis: 88 },
            { xAxis: 1, yAxis: 88 },
            { xAxis: 2, yAxis: 90 },
            { xAxis: 3, yAxis: 90 },
          ],
        },
        label: {
          // Adding labels for each bar
          show: true,
          position: "inside", // Adjust label position as needed
          formatter: function (params) {
            return params.value; // Display the value of each bar as label
          },
        },
      },
      {
        name: "Prev.Year",
        type: "bar",
        barGap: 0,
        emphasis: {
          focus: "series",
        },
       
      },
    ],
  };

  myChart9.setOption(option9);

  var myChart10 = echarts.init(document.getElementById("chartId10"));
  var option10 = {
    color: [
      {
        type: "linear",
        x: 0,
        y: 0,
        x2: 1,
        y2: 0,
        colorStops: colorStops.redOrange,
      },
      {
        type: "linear",
        x: 0,
        y: 0,
        x2: 1,
        y2: 0,
        colorStops: colorStops.greenShade,
      },
    ],
    grid: {
      top: 10,
      bottom: "20%",
      left: "20%",
      right: "10%",
    },

    legend: {
      bottom: 0,
      textStyle: {
        color: "white",
      },
      data: ["Oper.Cost",  "2023",{
        name: "Prev.Oper.Cost",
        icon: "rect",
        itemStyle: {
          color: "#4FC3F7", // Set the color to blue for the icon
        },
      },"Cost/MLD"],
      icon: "rect",
      itemWidth: 14,
      itemHeight: 10,
    },
    xAxis: [
      {
        type: "category",

        axisTick: { show: false },
        data: ["Jan", "Feb", "Mar", "Apr"],
        axisLine: {
          show: false,
          lineStyle: {
            color: "white",
          },
        },
      },
    ],
    yAxis: [
      {
        min: 0,
        max: 30,
        interval: 7.5,
        name: "Operating Cost (×1000 USD)",
        nameLocation: "middle",
        nameGap: 40,
        type: "value",
        splitNumber: 5,
        splitLine: {
          show: false,
        },
        axisLine: {
          show: false,
          lineStyle: {
            color: "white",
          },
        },
      },
      {
        type: "value",
        splitNumber: 5,
        nameLocation: "middle",
        nameGap: 30,
        min: 0.5,
        max: 1.5,
        interval: 0.2,
        name: "Cost/MLD (×1000 USD)",

        splitLine: {
          show: false,
        },
        axisLine: {
          show: false,
          lineStyle: {
            color: "white",
          },
        },
      },
    ],
    series: [
      {
        name: "Oper.Cost",
        type: "bar",
        barGap: 0,
        emphasis: {
          focus: "series",
        },
        data: [24, 22, 25, 26],
        markPoint: {
          symbol: "line",
          symbolSize: [50, 100],
          itemStyle: {
            color: "#4FC3F7 ",
          },
          data: [
            { xAxis: 0, yAxis: 24 },
            { xAxis: 1, yAxis: 22 },
            { xAxis: 2, yAxis: 25 },
            { xAxis: 3, yAxis: 26 },
          ],
        },
        label: {
          // Adding labels for each bar
          show: true,
          position: "inside", // Adjust label position as needed
          formatter: function (params) {
            return params.value; // Display the value of each bar as label
          },
          color: "white",
        },
      },
      {
        name: "Cost/MLD",
        type: "line",
        yAxisIndex: 1,
        emphasis: {
          focus: "series",
        },
        data: [1.2, 1.1, 1.3, 1.45],

        markPoint: {
          symbol: "line",
          symbolSize: [28, 50],

          lineWidth: 5,
          radius: 10,
          itemStyle: {
            color: "#4FC3F7 ",
          },
          // data: [
          //   { xAxis: 0, yAxis: 1.2 },
          //   { xAxis: 1, yAxis: 1.1 },
          //   { xAxis: 2, yAxis: 1.3 },
          //   { xAxis: 3, yAxis: 1.45 },
          // ],
        },
        label: {
          // Adding labels for each bar
          show: true,
          position: "inside", // Adjust label position as needed
          formatter: function (params) {
            return params.value; // Display the value of each bar as label
          },
          color: "white",
        },
      },
      {
        name: "Prev.Oper.Cost",
        type: "bar",
        barGap: 0,
        emphasis: {
          focus: "series",
        },
       
      },
    ],
  };
  myChart10.setOption(option10);
  var liquidChart = echarts.init(document.getElementById("chartId7"));

  // Configure the liquid gauge chart
  var option = {
    series: [
      {
        type: "liquidFill",
        itemStyle: {
          color: {
            type: "linear",
            x: 0,
            y: 0,
            x2: 1,
            y2: 0,
            colorStops: colors, // Use the defined colors for the gradient
          },
          // borderColor: "blue", // Outline color
          // borderWidth: 2, // Outline width
          // borderType: "solid",
          // opacity: 1,
        },

        data: ["0.66"], // Set the data value (e.g., 0.6 for 60%)
        radius: "70%", // Adjust the size of the liquid fill gauge
        center: ["50%", "50%"],
        label: {
          normal: {
            formatter: function (params) {
              return (params.value * 100).toFixed(0) + "%";
            },
            fontSize: 28,
            color: "#fff",
            align: "center",
            horizontalAlign: "center",
            padding: 20,
          },
        },

        backgroundStyle: {
          color: "transparent", // Set the background color to transparent
        },
        outline: {
          show: true,
          itemStyle: {
            borderColor: "#3DB6ED", // Hide the outline border
          },
        },
      },
    ],
  };

  // Set the chart options and render the chart
  liquidChart.setOption(option);
})(window.cwidget ? window.cwidget : cwidget);
