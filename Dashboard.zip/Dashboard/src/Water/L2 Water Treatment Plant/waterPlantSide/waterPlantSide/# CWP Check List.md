**How to use the checkbox:**  
The syntax '- [ ]' will create a clickable checkbox in the preview. This will create an empty checkbox. Once the task is completed add an 'x' inside brackerts and remove the blank space, i.e. '- [x]'.

# CWP Check List

- [ ] Add a parameter for data
- [ ] Integrate API for data
- [ ] Integrate data input from System Platform
- [ ] Supply API URL from System Platform with default set.
