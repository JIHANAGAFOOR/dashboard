// Initialise the package with data.
let cwidget = {
  data: [],
};
// This function is used for interaction with a global object called 'cwidget', that will be created during packaging into CWP.
// Any function or code that need to be interacted with System Platform or API, need to be inside this.
(function (cwidget) {})(window.cwidget ? window.cwidget : cwidget);
