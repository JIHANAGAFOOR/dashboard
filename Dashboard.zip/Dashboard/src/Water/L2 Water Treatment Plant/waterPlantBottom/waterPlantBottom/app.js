// Initialise the package with data.
const colorStops = {
  // For multi data charts
  pinkPurple: [
    {
      offset: 0,
      color: "hsla(306, 66%, 65%, 1)", // color at 0%: Pink
    },
    {
      offset: 1,
      color: "hsla(311, 87%, 35%, 1)", // color at 100%: Purple
    },
  ],
  blueViolet: [
    {
      offset: 0,
      color: "hsla(241, 68%, 61%, 1)", // color at 0%: Blue
    },
    {
      offset: 1,
      color: "hsla(274, 68%, 61%, 1)", // color at 100%: Violet
    },
  ],
  cyanBlue: [
    {
      offset: 0,
      color: "hsla(158, 63%, 69%, 1)", // color at 0%: Cyan
    },
    {
      offset: 1,
      color: "hsla(205, 65%, 60%, 1)", // color at 100%: Blue
    },
  ],
  yellowGreen: [
    {
      offset: 0,
      color: "hsla(75, 61%, 64%, 1)", // color at 0%: Yellow
    },
    {
      offset: 1,
      color: "hsla(119, 47%, 50%, 1)", // color at 100%: Blue
    },
  ],
  redOrange: [
    {
      offset: 0,
      color: "hsla(0, 69%, 59%, 1)", // color at 0%: Red
    },
    {
      offset: 1,
      color: "hsla(32, 62%, 60%, 1)", // color at 100%: Orange
    },
  ],
  // For two element complimentary charts
  redShade: [
    {
      offset: 0,
      color: "hsla(345, 74%, 63%, 1)", // color at 0%: Pinkish Red
    },
    {
      offset: 1,
      color: "hsla(15, 73%, 64%, 1)", // color at 100%: Orange Shift
    },
  ],
  greenShade: [
    {
      offset: 0,
      color: "hsla(114, 64%, 61%, 1)", // color at 0%: Light Green
    },
    {
      offset: 1,
      color: "hsla(162, 54%, 46%, 1)", // color at 100%: Blueish green
    },
  ],
  // Continuous gradient for meter.
  redYellowGreen: [
    {
      offset: 0,
      color: "hsla(11, 71%, 62%, 1)", // color at 0%: Light Green
    },
    {
      offset: 0.5,
      color: "hsla(59, 678%, 71%, 1)", // color at 0%: Light Green
    },
    {
      offset: 1,
      color: "hsla(112, 64%, 61%, 1)", // color at 100%: Blueish green
    },
  ],
  lightBlueViolet: [
    {
      offset: 0,
      color: "hsla(194, 80%, 61%, 1)", // color at 0%: Cyan
    },
    {
      offset: 1,
      color: "hsla(266, 68%, 65%, 1)", // color at 100%: Violet
    },
  ],
};

let cwidget = {
  data: [],
};
// This function is used for interaction with a global object called 'cwidget', that will be created during packaging into CWP.
// Any function or code that need to be interacted with System Platform or API, need to be inside this.
(function (cwidget) {
  let recoveryChart = echarts.init(document.getElementById("Recovery"));
  let label = "92%";
  let recoveryChartOptions = {
    color: [
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 1,
        y2: 0,
        colorStops: colorStops.redYellowGreen,
      },
      "hsla(0, 0%, 90%, 0.16)",
    ],
    // legend: {
    //   top: "5%",
    //   left: "center",
    // },
    series: [
      {
        name: "Access From",
        type: "pie",
        radius: ["60%", "100%"],
        center: ["50%", "80%"],
        startAngle: 180,
        endAngle: 360,
        labelLine: {
          show: false,
        },
        label: {
          color: "#FFF",
          fontSize: "15",
          position: "center",
          formatter: () => {
            return label; // Direct label without dynamic data
          },
        },
        // Omitting dynamic data
        data: [
          { value: 92, name: "Example A" }, // Static example values
          { value: 8, name: "Example B" }, // for demonstration purposes
        ],
      },
    ],
  };
  recoveryChart.setOption(recoveryChartOptions);

  window.addEventListener("resize", function () {
    recoveryChart.resize();
  });

  let capacityChart = echarts.init(document.getElementById("capacity"));
  let label1 = "95%";
  let capacityChartOptions = {
    color: [
      {
        type: "linear",
        x: 0,
        y: 0,
        x2: 1,
        y2: 0,
        colorStops: colorStops.redYellowGreen,
      },
      "hsla(0, 0%, 90%, 0.16)",
    ],
    // legend: {
    //   top: "5%",
    //   left: "center",
    // },
    series: [
      {
        name: "Access From",
        type: "pie",
        radius: ["60%", "100%"],
        center: ["50%", "80%"],
        startAngle: 180,
        endAngle: 360,
        labelLine: {
          show: false,
        },
        label: {
          color: "#FFF",
          fontSize: "15",
          position: "center",
          formatter: () => {
            return label1; // Direct label without dynamic data
          },
        },
        // Omitting dynamic data
        data: [
          { value: 95, name: "Example C" }, // Static example values
          { value: 5, name: "Example D" }, // for demonstration purposes
        ],
      },
    ],
  };
  capacityChart.setOption(capacityChartOptions);

  window.addEventListener("resize", function () {
    capacityChart.resize();
  });
})(window.cwidget ? window.cwidget : cwidget);
