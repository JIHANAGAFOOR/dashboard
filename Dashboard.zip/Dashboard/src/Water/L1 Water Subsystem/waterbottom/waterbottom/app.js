// Initialise the package with data.

const colorStops = {
  // For multi data charts
  pinkPurple: [
    {
      offset: 0,
      color: "hsla(306, 66%, 65%, 1)", // color at 0%: Pink
    },
    {
      offset: 1,
      color: "hsla(311, 87%, 35%, 1)", // color at 100%: Purple
    },
  ],
  blueViolet: [
    {
      offset: 0,
      color: "hsla(241, 68%, 61%, 1)", // color at 0%: Blue
    },
    {
      offset: 1,
      color: "hsla(274, 68%, 61%, 1)", // color at 100%: Violet
    },
  ],
  cyanBlue: [
    {
      offset: 0,
      color: "hsla(158, 63%, 69%, 1)", // color at 0%: Cyan
    },
    {
      offset: 1,
      color: "hsla(205, 65%, 60%, 1)", // color at 100%: Blue
    },
  ],
  lightgreen: [
    {
      offset: 0,
      color: "#7EE2BE", // color at 0%: Pink
    },
    {
      offset: 1,
      color: "#58A5DC", // color at 100%: Purple
    },
  ],
};
let cwidget = {
  data: [],
};
// This function is used for interaction with a global object called 'cwidget', that will be created during packaging into CWP.
// Any function or code that need to be interacted with System Platform or API, need to be inside this.
(function (cwidget) {
  let value = 438;
  let customerChart = echarts.init(document.getElementById("customer"));

  let customerChartOptions = {
    color: [
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.pinkPurple,
      },
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.blueViolet,
      },
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.cyanBlue,
      },
    ],
    legend: {
      // orient: "horizontal", // Set legend orientation to horizontal
      bottom: 0, // Adjust bottom position
      left: "center", // Center the legend horizontally
      textStyle: {
        color: "white", // Set legend text color to white
      },
    },

    graphic: [
      {
        type: "text",
        left: "center",
        top: "40%",
        style: {
          text: "Total: " + value,
          fill: "white",
          fontSize: 8,
          fontWeight: "bold",
        },
      },
    ],
    series: [
      {
        type: "pie",
        labelLine: {
          show: false,
        },
        radius: ["40%", "75%"],
        center: ["50%", "42%"], // This creates the doughnut chart effect
        data: [
          { value: "16", name: "Open" },
          { value: "32", name: "Closed" },
          { value: "52", name: "In-Progress" },
        ],
        // Optional: to improve label visibility and aesthetics
        label: {
          position: "inside",
          formatter: " {d}% ",
          color: "white",
          fontSize: 8,
        },
      },
    ],
  };

  customerChart.setOption(customerChartOptions);

  window.addEventListener("resize", function () {
    customerChart.resize();
  });
  let FinanceChart = echarts.init(document.getElementById("Finance"));

  let FinanceChartOptions = {
    color: [
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.lightgreen,
      },
    ],
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "shadow",
      },
    },
    legend: {
      bottom: "0",
      // top: "81%",
      textStyle: {
        color: "white", // Set legend text color to white
      },
    },
    grid: {
      left: "20%",
      right: "10%",
      bottom: "30%",
      top: "0%",
      containLabel: false,
    },
    xAxis: {
      type: "value",
      boundaryGap: [0, 0.01],
      axisLabel: {
        color: "white", // Set y-axis label color to white
      },
      splitLine: {
        show: false, // Hide x-axis grid lines
      },
    },
    yAxis: {
      type: "category",
      data: ["Zone 5", "Zone 4", "Zone 3", "Zone 2", "Zone 1"],
      axisLabel: {
        color: "white", // Set y-axis label color to white
      },
    },
    series: [
      {
        name: "",
        type: "bar",
        data: [2.9, 3.1, 2.6, 2.7, 2.4],
        label: {
          show: true,
          position: "outside",
          color: "white", // Adjust position as needed
        },
      },
    ],
  };

  FinanceChart.setOption(FinanceChartOptions);

  window.addEventListener("resize", function () {
    FinanceChart.resize();
  });
})(window.cwidget ? window.cwidget : cwidget);
