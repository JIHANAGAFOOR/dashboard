// Initialise the package with data.
let cwidget = {
  data: [],
};
const colorStops = {
  // For multi data charts
  yellowShade: [
    {
      offset: 0,
      color: "#DACE81",
    },
    {
      offset: 1,
      color: "#C9A445",
    },
  ],
  blueShade: [
    {
      offset: 0,
      color: "#7EE2BE",
    },
    {
      offset: 1,
      color: "#58A5DC",
    },
  ],
  pinkPurple: [
    {
      offset: 0,
      color: "hsla(306, 66%, 65%, 1)", // color at 0%: Pink
    },
    {
      offset: 1,
      color: "hsla(311, 87%, 35%, 1)", // color at 100%: Purple
    },
  ],
  blueViolet: [
    {
      offset: 0,
      color: "hsla(241, 68%, 61%, 1)", // color at 0%: Blue
    },
    {
      offset: 1,
      color: "hsla(274, 68%, 61%, 1)", // color at 100%: Violet
    },
  ],
  cyanBlue: [
    {
      offset: 0,
      color: "hsla(158, 63%, 69%, 1)", // color at 0%: Cyan
    },
    {
      offset: 1,
      color: "hsla(205, 65%, 60%, 1)", // color at 100%: Blue
    },
  ],
  yellowGreen: [
    {
      offset: 0,
      color: "hsla(75, 61%, 64%, 1)", // color at 0%: Yellow
    },
    {
      offset: 1,
      color: "hsla(119, 47%, 50%, 1)", // color at 100%: Blue
    },
  ],
  redOrange: [
    {
      offset: 0,
      color: "hsla(0, 69%, 59%, 1)", // color at 0%: Red
    },
    {
      offset: 1,
      color: "hsla(32, 62%, 60%, 1)", // color at 100%: Orange
    },
  ],
  // For two element complimentary charts
  redShade: [
    {
      offset: 0,
      color: "hsla(345, 74%, 63%, 1)", // color at 0%: Pinkish Red
    },
    {
      offset: 1,
      color: "hsla(15, 73%, 64%, 1)", // color at 100%: Orange Shift
    },
  ],
  greenShade: [
    {
      offset: 0,
      color: "hsla(114, 64%, 61%, 1)", // color at 0%: Light Green
    },
    {
      offset: 1,
      color: "hsla(162, 54%, 46%, 1)", // color at 100%: Blueish green
    },
  ],
  // Continuous gradient for meter.
  redYellowGreen: [
    {
      offset: 0,
      color: "hsla(11, 71%, 62%, 1)", // color at 0%: Light Green
    },
    {
      offset: 0.5,
      color: "hsla(59, 678%, 71%, 1)", // color at 0%: Light Green
    },
    {
      offset: 1,
      color: "hsla(112, 64%, 61%, 1)", // color at 100%: Blueish green
    },
  ],
  lightBlueViolet: [
    {
      offset: 0,
      color: "hsla(194, 80%, 61%, 1)", // color at 0%: Cyan
    },
    {
      offset: 1,
      color: "hsla(266, 68%, 65%, 1)", // color at 100%: Violet
    },
  ],
};
// This function is used for interaction with a global object called 'cwidget', that will be created during packaging into CWP.
// Any function or code that need to be interacted with System Platform or API, need to be inside this.
(function (cwidget) {
  //Analytics charts
  let value1 = "53.8Mgl";

  var chartDom1 = document.getElementById("chartId2");
  var myChart1 = echarts.init(chartDom1);
  var option1;

  option1 = {
    color: [
      // Gradients
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.redOrange,
      },
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.yellowGreen,
      },
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.blueViolet,
      },
    ],
    grid: {
      top: 0,
      bottom: 20,
      left: "10%",
      right: "10%",
    },
    // tooltip: {
    //   trigger: "item",
    // },
    legend: {
      itemWidth: 10, // Change the width of legend icon
      itemHeight: 8,
      top: "78%",
      textStyle: {
        fontSize: 10,
        color: "white",
      },
    },
    graphic: [
      {
        type: "text",
        left: "center",
        top: "30%",
        style: {
          text: " Total:\n" + value1,
          fill: "white",
          fontSize: 8,
          fontWeight: "bold",
        },
      },
    ],
    series: [
      {
        name: "Access From",
        type: "pie",
        radius: ["35%", "72%"],
        center: ["50%", "40%"],
        avoidLabelOverlap: false,

        label: {
          color: "#FFF",
          fontSize: "10",
          position: "inside",
          formatter: "{d}%",
        },

        labelLine: {
          show: false,
        },
        data: [
          { value: "14", name: "Multiple Family" },
          { value: "28", name: "Single Family" },
          { value: " 58", name: "Irrigation" },
        ],
      },
    ],
  };
  option1 && myChart1.setOption(option1);

  var chartDom2 = document.getElementById("chartId3");
  var myChart2 = echarts.init(chartDom2);
  var option2;

  const data = [
    43.45, 37.9, 41.6, 42.42, 44, 43.93, 43.3, 44.6, 42.95, 41.82, 43.35, 42.81, 41.26, 46.94, 44.94, 49.02, 46.23, 43.33, 44.38, 41.8, 39.28, 41.51,
    40.19, 41.51, 41.26, 42.45, 41.22, 41.75, 40.9, 38.55, 43, 38.28, 36.74, 38.03, 35.92, 39.31, 37.93, 39.96, 35.74, 41.3, 40.29, 35.16, 43.84,
    37.41, 38.39, 35.39, 38.8, 35.85, 38.08, 34.77, 41.57, 39.51, 36.04, 42.87, 36.33, 39.26, 34.81, 35.78,
  ];

  function generateData() {
    for (var i = 0; i <= 10; i++) {
      data.push(Math.random() * 100); // Random data points
    }
    return data;
  }
  option2 = {
    grid: {
      top: 10,
      left: "20%",
      right: "20%",
      bottom: 18,
    },
    tooltip: {
      trigger: "axis",
    },
    xAxis: {
      type: "category",
      data: [2018, 2019, 2020, 2021, 2022, 2023, 2024],
      axisLabel: {
        color: "white",
      },
      axisTick: {
        show: false,
      },
      axisLine: {
        show: false,
      },
    },
    yAxis: {
      min: 0,
      max: 50,
      interval: 15,
      type: "value",
      splitLine: {
        show: false,
      },
      axisLabel: {
        color: "white",
      },
    },
    series: [
      {
        type: "line",
        data: generateData(),
        symbol: "none", // No data points symbol
        lineStyle: {
          height: 1,
          width: 2,
          color: "hsla(120, 100%, 50%, 0.8)",

          smooth: true,
        },
      },
    ],
  };
  setInterval(function () {
    option2.series[0].data = generateData();
    myChart2.setOption(option2);
  }, 1000);
  option2 && myChart2.setOption(option2);

  var chartDom4 = document.getElementById("chartId4");
  var myChart4 = echarts.init(chartDom4);
  var option4;

  option4 = {
    color: [
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.blueViolet,
      },
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.cyanBlue,
      },
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.redOrange,
      },
    ],

    legend: {
      itemWidth: 10, // Change the width of legend icon
      itemHeight: 8,
      top: "78%",
      textStyle: {
        fontSize: 10,
        color: "white",
      },
    },
    // tooltip: {
    //   trigger: "item",
    // },
    series: [
      {
        name: "Access From",
        type: "pie",
        radius: ["35%", "72%"],
        center: ["50%", "40%"],
        avoidLabelOverlap: false,

        label: {
          position: "inside",
          formatter: "{d}%",
          color: "white",
          fontSize: 10,
        },

        labelLine: {
          show: false,
        },
        data: [
          { value: "72", name: "Public House" },
          { value: "16", name: "Industrial" },
          { value: "12", name: "Household" },
        ],
      },
    ],
  };
  option4 && myChart4.setOption(option4);

  //RealTime charts
  var chartDom5 = document.getElementById("chart1");

  window.addEventListener("resize", function () {
    chartDom5.resize();
  });
  var myChart5 = echarts.init(chartDom5);
  var option5;

  option5 = {
    color: [
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.blueViolet,
      },
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.blueShade,
      },
    ],
    grid: {
      top: 5,
      bottom: 60,
      left: "30%",
      right: "5%",
    },
    legend: {
      // position: "top",
      top: "88%",
      left: "30%",
      textStyle: {
        color: "white",
      },
    },
    tooltip: {},
    dataset: {
      source: [
        ["product", "Rated", "Current"],
        ["South East", 90, 90],
        ["Ocean\nside", 120, 112],
        ["Treasure\nIsland", 80, 78],
        ["Me Leong", 110, 103],
        ["Marina \nDistrict", 100, 100],
      ],
    },
    xAxis: {
      nameLocation: "middle",
      nameGap: 25,
      min: 0,
      max: 120,
      nameTextStyle: {
        color: "white",
      },
      boundaryGap: [0, 0.01],
      axisLabel: {
        color: "white", // Set y-axis label color to white
      },
      axisLine: {
        show: false,
      },
      axisTick: {
        show: false,
      },
      splitLine: {
        show: false, // Hide x-axis grid lines
      },
    },
    yAxis: {
      type: "category",
      // min: 0,
      // max: 140,
      // interval: 35,

      nameLocation: "middle",
      nameGap: 40,
      nameTextStyle: {
        color: "white",
      },
      axisLabel: {
        color: "white", // Set y-axis label color to white
      },
      axisLine: {
        show: false,
      },
      axisTick: {
        show: false,
      },
      splitLine: {
        show: false, // Hide x-axis grid lines
      },
    },
    // Declare several bar series, each will be mapped
    // to a column of dataset.source by default.
    series: [
      {
        type: "bar",
        barGap: 0,
        label: {
          show: true,
          position: "inside",
          color: "white", // Adjust position as needed
        },
      },
      {
        type: "bar",
        label: {
          show: true,
          position: "inside",
          color: "white", // Adjust position as needed
        },
      },
    ],
  };

  option5 && myChart5.setOption(option5);

  var chartDom6 = document.getElementById("chart2");
  var myChart6 = echarts.init(chartDom6);
  var option6;

  option6 = {
    grid: {
      top: 10,
      left: 10,
      bottom: 10,
      right: 10,
    },
    tooltip: {},
    radar: {
      indicator: [
        { name: "South East", max: 100 },
        { name: "Ocean\nside", max: 100 },
        { name: "Treasure\nIsland", max: 100 },
        { name: "Me Leong", max: 100 },
        { name: "Marina \nDistrict", max: 100 },
      ],
      radius: "65%",
      center: ["50%", "60%"],
      splitLine: {
        lineStyle: {
          color: "hsla(120, 100%, 50%, 0.8)",
        },
      },
    },
    series: [
      {
        type: "radar",
        data: [
          {
            value: [78, 64, 82, 62, 95],
            name: "Plant Efficiency",
          },
        ],
        itemStyle: {
          color: "hsla(120, 100%, 50%, 0.8)",
        },
        label: {
          show: true,
          color: "white",
          formatter: function (params) {
            return params.value + "%";
          },
        },
      },
    ],
  };

  option6 && myChart6.setOption(option6);

  var chartDom7 = document.getElementById("chart3");
  var myChart7 = echarts.init(chartDom7);
  var option7;

  option7 = {
    color: [
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.redShade,
      },
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.greenShade,
      },
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.yellowShade,
      },
    ],
    grid: {
      top: 10,
      bottom: 60,
      left: "10%",
      right: "10%",
    },
    legend: {
      top: "88%",
      textStyle: {
        color: "white",
      },
    },
    tooltip: {},
    dataset: {
      source: [
        ["product", "Demand", "Supply", "Gap"],
        ["Zone 1", 14, 12, 2],
        ["Zone 2", 16, 13, 3],
        ["Zone 3", 17, 16, 1],
        ["Zone 4", 15, 11, 4],
        ["Zone 5", 16, 14, 2],
      ],
    },
    xAxis: {
      type: "category",
      boundaryGap: [0, 0.01],
      axisLabel: {
        color: "white", // Set y-axis label color to white
      },
      axisLine: {
        show: false,
      },
      axisTick: {
        show: false,
      },
      splitLine: {
        show: false, // Hide x-axis grid lines
      },
    },
    yAxis: {
      max: 20,
      name: "Vol of Water (Mgl/day)",
      nameLocation: "middle",
      nameGap: 40,
      nameTextStyle: {
        color: "white",
      },
      // type: "category",
      // data: ["Level3", "Level2"],
      axisLabel: {
        color: "white", // Set y-axis label color to white
      },
      splitLine: {
        show: false, // Hide x-axis grid lines
      },
    },
    // Declare several bar series, each will be mapped
    // to a column of dataset.source by default.
    series: [
      {
        type: "bar",
        barGap: 0,
        label: {
          show: true,
          position: "outside",
          color: "white", // Adjust position as needed
        },
      },
      {
        type: "bar",
        label: {
          show: true,
          position: "outside",
          color: "white", // Adjust position as needed
        },
      },
      {
        type: "bar",
        label: {
          show: true,
          position: "outside",
          color: "white", // Adjust position as needed
        },
      },
    ],
  };

  option7 && myChart7.setOption(option7);
})(window.cwidget ? window.cwidget : cwidget);
