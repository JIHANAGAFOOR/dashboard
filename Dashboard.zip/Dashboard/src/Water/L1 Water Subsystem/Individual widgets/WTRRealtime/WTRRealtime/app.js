// Initialise the package with data.
let cwidget = {
  data: [],
};
// This function is used for interaction with a global object called 'cwidget', that will be created during packaging into CWP.
// Any function or code that need to be interacted with System Platform or API, need to be inside this.

const colorStops = {
  blueViolet: [
    {
      offset: 0,
      color: "#5A57DF",
    },
    {
      offset: 1,
      color: "#A459DF",
    },
  ],
  blueShade: [
    {
      offset: 0,
      color: "#7EE2BE",
    },
    {
      offset: 1,
      color: "#58A5DC",
    },
  ],
  redShade: [
    {
      offset: 0,
      color: "#E65B7E",
    },
    {
      offset: 1,
      color: "#E68260",
    },
  ],
  greenShade: [
    {
      offset: 0,
      color: "#69DB5C",
    },
    {
      offset: 1,
      color: "#36B58F",
    },
  ],
  yellowShade: [
    {
      offset: 0,
      color: "#DACE81",
    },
    {
      offset: 1,
      color: "#C9A445",
    },
  ],
};
(function (cwidget) {
  var chartDom = document.getElementById("chartId1");
  var myChart = echarts.init(chartDom);
  var option;

  option = {
    color: [
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.blueViolet,
      },
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.blueShade,
      },
    ],
    grid: {
      top: 10,
      bottom: 40,
      left: "20%",
      // right: "10%",
    },
    legend: {
      top: "88%",
      textStyle: {
        color: "white",
      },
    },
    tooltip: {},
    dataset: {
      source: [
        ["product", "Rated", "Current"],
        ["Plant 1", 90, 90],
        ["Plant 2", 120, 112],
        ["Plant 3", 80, 78],
        ["Plant 4", 110, 103],
        ["Plant 5", 100, 100],
      ],
    },
    xAxis: {
      type: "category",
      boundaryGap: [0, 0.01],
      axisLabel: {
        color: "white", // Set y-axis label color to white
      },
      axisLine: {
        show: false,
      },
      axisTick: {
        show: false,
      },
      splitLine: {
        show: false, // Hide x-axis grid lines
      },
    },
    yAxis: {
      min: 0,
      max: 140,
      interval: 35,
      name: "Plant Capacity (MLD)",
      nameLocation: "middle",
      nameGap: 40,
      nameTextStyle: {
        color: "white",
      },
      axisLabel: {
        color: "white", // Set y-axis label color to white
      },
      splitLine: {
        show: false, // Hide x-axis grid lines
      },
    },
    // Declare several bar series, each will be mapped
    // to a column of dataset.source by default.
    series: [
      {
        type: "bar",
        barGap: 0,
        label: {
          show: true,
          position: "inside",
          color: "white", // Adjust position as needed
        },
      },
      {
        type: "bar",
        label: {
          show: true,
          position: "inside",
          color: "white", // Adjust position as needed
        },
      },
    ],
  };

  option && myChart.setOption(option);

  var chartDom = document.getElementById("chartId2");
  var myChart = echarts.init(chartDom);
  var option;

  option = {
    tooltip: {},
    radar: {
      indicator: [
        { name: "Plant 1", max: 100 },
        { name: "Plant 2", max: 100 },
        { name: "Plant 3", max: 100 },
        { name: "Plant 4", max: 100 },
        { name: "Plant 5", max: 100 },
      ],
      radius: "65%",
      center: ["50%", "60%"],
      splitLine: {
        lineStyle: {
          color: "hsla(120, 100%, 50%, 0.8)",
        },
      },
    },
    series: [
      {
        type: "radar",
        data: [
          {
            value: [78, 64, 82, 62, 95],
            name: "Plant Efficiency",
          },
        ],
        itemStyle: {
          color: "hsla(120, 100%, 50%, 0.8)",
        },
        label: {
          show: true,
          color: "white",
          formatter: function (params) {
            return params.value + "%";
          },
        },
      },
    ],
  };

  option && myChart.setOption(option);

  var chartDom = document.getElementById("chartId3");
  var myChart = echarts.init(chartDom);
  var option;

  option = {
    color: [
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.redShade,
      },
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.greenShade,
      },
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.yellowShade,
      },
    ],
    grid: {
      top: 18,
      bottom: 40,
      left: "20%",
      // right: "10%",
    },
    legend: {
      top: "88%",
      textStyle: {
        color: "white",
      },
    },
    tooltip: {},
    dataset: {
      source: [
        ["product", "Demand", "Supply", "Gap"],
        ["Zone 1", 14, 12, 2],
        ["Zone 2", 16, 13, 3],
        ["Zone 3", 17, 16, 1],
        ["Zone 4", 15, 11, 4],
        ["Zone 5", 16, 14, 2],
      ],
    },
    xAxis: {
      type: "category",
      boundaryGap: [0, 0.01],
      axisLabel: {
        color: "white", // Set y-axis label color to white
      },
      axisLine: {
        show: false,
      },
      axisTick: {
        show: false,
      },
      splitLine: {
        show: false, // Hide x-axis grid lines
      },
    },
    yAxis: {
      max: 20,
      name: "Vol of Water (Mgl/day)",
      nameLocation: "middle",
      nameGap: 40,
      nameTextStyle: {
        color: "white",
      },
      // type: "category",
      // data: ["Level3", "Level2"],
      axisLabel: {
        color: "white", // Set y-axis label color to white
      },
      splitLine: {
        show: false, // Hide x-axis grid lines
      },
    },
    // Declare several bar series, each will be mapped
    // to a column of dataset.source by default.
    series: [
      {
        type: "bar",
        barGap: 0,
        label: {
          show: true,
          position: "outside",
          color: "white", // Adjust position as needed
        },
      },
      {
        type: "bar",
        label: {
          show: true,
          position: "outside",
          color: "white", // Adjust position as needed
        },
      },
      {
        type: "bar",
        label: {
          show: true,
          position: "outside",
          color: "white", // Adjust position as needed
        },
      },
    ],
  };

  option && myChart.setOption(option);
})(window.cwidget ? window.cwidget : cwidget);
