// Initialise the package with data.

const colorStops = {
  // For multi data charts
  pinkPurple: [
    {
      offset: 0,
      color: "hsla(306, 66%, 65%, 1)", // color at 0%: Pink
    },
    {
      offset: 1,
      color: "hsla(311, 87%, 35%, 1)", // color at 100%: Purple
    },
  ],
  blueViolet: [
    {
      offset: 0,
      color: "hsla(241, 68%, 61%, 1)", // color at 0%: Blue
    },
    {
      offset: 1,
      color: "hsla(274, 68%, 61%, 1)", // color at 100%: Violet
    },
  ],
  cyanBlue: [
    {
      offset: 0,
      color: "hsla(158, 63%, 69%, 1)", // color at 0%: Cyan
    },
    {
      offset: 1,
      color: "hsla(205, 65%, 60%, 1)", // color at 100%: Blue
    },
  ],
};
let cwidget = {
  data: [],
};
// This function is used for interaction with a global object called 'cwidget', that will be created during packaging into CWP.
// Any function or code that need to be interacted with System Platform or API, need to be inside this.
(function (cwidget) {
  let value = 438;
  let customerChart = echarts.init(document.getElementById("customer"));

  let customerChartOptions = {
    color: [
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.pinkPurple,
      },
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.blueViolet,
      },
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.cyanBlue,
      },
    ],
    legend: {
      // orient: "horizontal", // Set legend orientation to horizontal
      bottom: 22, // Adjust bottom position
      left: "center", // Center the legend horizontally
      textStyle: {
        color: "white", // Set legend text color to white
      },
    },

    graphic: [
      {
        type: "text",
        left: "center",
        top: "40%",
        style: {
          text: "Total: " + value,
          fill: "white",
          fontSize: 16,
          fontWeight: "bold",
        },
      },
    ],
    series: [
      {
        type: "pie",
        labelLine: {
          show: false,
        },
        radius: ["40%", "80%"],
        center: ["50%", "40%"], // This creates the doughnut chart effect
        data: [
          { value: 86, name: "Open" },
          { value: 150, name: "Closed" },
          { value: 45, name: "In-Progress" },
        ],
        // Optional: to improve label visibility and aesthetics
        label: {
          position: "inside",
          formatter: " {d}% ",
          color: "white",
          fontSize: 13,
        },
      },
    ],
  };

  customerChart.setOption(customerChartOptions);

  window.addEventListener("resize", function () {
    customerChart.resize();
  });
})(window.cwidget ? window.cwidget : cwidget);
