// Initialise the package with data.

const colorStops = {
  // For multi data charts
  lightgreen: [
    {
      offset: 0,
      color: "#7EE2BE", // color at 0%: Pink
    },
    {
      offset: 1,
      color: "#58A5DC", // color at 100%: Purple
    },
  ],
};
let cwidget = {
  data: [],
};
// This function is used for interaction with a global object called 'cwidget', that will be created during packaging into CWP.
// Any function or code that need to be interacted with System Platform or API, need to be inside this.
(function (cwidget) {
  let FinanceChart = echarts.init(document.getElementById("Finance"));

  let FinanceChartOptions = {
    color: [
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.lightgreen,
      },
    ],
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "shadow",
      },
    },
    legend: {
      bottom: "0",
      // top: "81%",
      textStyle: {
        color: "white", // Set legend text color to white
      },
    },
    grid: {
      left: "20%",
      right: "10%",
      bottom: "30%",
      top: "0%",
      containLabel: false,
    },
    xAxis: {
      type: "value",
      boundaryGap: [0, 0.01],
      axisLabel: {
        color: "white", // Set y-axis label color to white
      },
      splitLine: {
        show: false, // Hide x-axis grid lines
      },
    },
    yAxis: {
      type: "category",
      data: ["Zone 5", "Zone 4", "Zone 3", "Zone 2", "Zone 1"],
      axisLabel: {
        color: "white", // Set y-axis label color to white
      },
    },
    series: [
      {
        name: "",
        type: "bar",
        data: [2.9, 3.1, 2.6, 2.7, 2.4],
        label: {
          show: true,
          position: "outside",
          color: "white", // Adjust position as needed
        },
      },
    ],
  };

  FinanceChart.setOption(FinanceChartOptions);

  window.addEventListener("resize", function () {
    FinanceChart.resize();
  });
})(window.cwidget ? window.cwidget : cwidget);
