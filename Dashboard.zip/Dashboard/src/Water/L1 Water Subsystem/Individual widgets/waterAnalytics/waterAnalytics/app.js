// Initialise the package with data.
let cwidget = {
  data: [],
};
const colorStops = {
  // For multi data charts
  pinkPurple: [
    {
      offset: 0,
      color: "hsla(306, 66%, 65%, 1)", // color at 0%: Pink
    },
    {
      offset: 1,
      color: "hsla(311, 87%, 35%, 1)", // color at 100%: Purple
    },
  ],
  blueViolet: [
    {
      offset: 0,
      color: "hsla(241, 68%, 61%, 1)", // color at 0%: Blue
    },
    {
      offset: 1,
      color: "hsla(274, 68%, 61%, 1)", // color at 100%: Violet
    },
  ],
  cyanBlue: [
    {
      offset: 0,
      color: "hsla(158, 63%, 69%, 1)", // color at 0%: Cyan
    },
    {
      offset: 1,
      color: "hsla(205, 65%, 60%, 1)", // color at 100%: Blue
    },
  ],
  yellowGreen: [
    {
      offset: 0,
      color: "hsla(75, 61%, 64%, 1)", // color at 0%: Yellow
    },
    {
      offset: 1,
      color: "hsla(119, 47%, 50%, 1)", // color at 100%: Blue
    },
  ],
  redOrange: [
    {
      offset: 0,
      color: "hsla(0, 69%, 59%, 1)", // color at 0%: Red
    },
    {
      offset: 1,
      color: "hsla(32, 62%, 60%, 1)", // color at 100%: Orange
    },
  ],
  // For two element complimentary charts
  redShade: [
    {
      offset: 0,
      color: "hsla(345, 74%, 63%, 1)", // color at 0%: Pinkish Red
    },
    {
      offset: 1,
      color: "hsla(15, 73%, 64%, 1)", // color at 100%: Orange Shift
    },
  ],
  greenShade: [
    {
      offset: 0,
      color: "hsla(114, 64%, 61%, 1)", // color at 0%: Light Green
    },
    {
      offset: 1,
      color: "hsla(162, 54%, 46%, 1)", // color at 100%: Blueish green
    },
  ],
  // Continuous gradient for meter.
  redYellowGreen: [
    {
      offset: 0,
      color: "hsla(11, 71%, 62%, 1)", // color at 0%: Light Green
    },
    {
      offset: 0.5,
      color: "hsla(59, 678%, 71%, 1)", // color at 0%: Light Green
    },
    {
      offset: 1,
      color: "hsla(112, 64%, 61%, 1)", // color at 100%: Blueish green
    },
  ],
  lightBlueViolet: [
    {
      offset: 0,
      color: "hsla(194, 80%, 61%, 1)", // color at 0%: Cyan
    },
    {
      offset: 1,
      color: "hsla(266, 68%, 65%, 1)", // color at 100%: Violet
    },
  ],
};
// This function is used for interaction with a global object called 'cwidget', that will be created during packaging into CWP.
// Any function or code that need to be interacted with System Platform or API, need to be inside this.
(function (cwidget) {
  let value1 = "53.8Mgl";

  var chartDom = document.getElementById("chartId2");
  var myChart = echarts.init(chartDom);
  var option;

  option = {
    color: [
      // Gradients
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.redOrange,
      },
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.yellowGreen,
      },
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.blueViolet,
      },
    ],
    grid: {
      top: "10%",
      bottom: 17,
      left: "10%",
      right: "10%",
    },
    tooltip: {
      trigger: "item",
    },
    legend: {
      itemWidth: 10, // Change the width of legend icon
      itemHeight: 8,
      top: "80%",
      textStyle: {
        fontSize: 8,
        color: "white",
      },
    },
    graphic: [
      {
        type: "text",
        left: "center",
        top: "30%",
        style: {
          text: " Total:\n" + value1,
          fill: "white",
          fontSize: 8,
          fontWeight: "bold",
        },
      },
    ],
    series: [
      {
        name: "Access From",
        type: "pie",
        radius: ["50%", "80%"],
        center: ["50%", "40%"],
        avoidLabelOverlap: false,

        label: {
          color: "#FFF",
          fontSize: "8",
          position: "inside",
          formatter: "{d}%",
        },

        labelLine: {
          show: false,
        },
        data: [
          { value: 20, name: "Multiple Family" },
          { value: 28, name: "Single Family" },
          { value: 5.8, name: "Irrigation" },
        ],
      },
    ],
  };
  option && myChart.setOption(option);

  var chartDom2 = document.getElementById("chartId3");
  var myChart2 = echarts.init(chartDom2);
  var option2;
  // prettier-ignore

  function randomData() {
    now = new Date(+now + oneDay);
    value = value + Math.random() * 21 - 10;
    return {
      name: now.toString(),
      value: [[now.getFullYear(), now.getMonth() + 1, now.getDate()].join("/"), Math.round(value)],
    };
  }
  const data = [
    10.45, 37.9, 41.6, 42.42, 44, 43.93, 43.3, 44.6, 42.95, 41.82, 43.35, 42.81, 41.26, 46.94, 44.94, 49.02, 46.23, 43.33, 44.38, 41.8, 39.28, 41.51,
    40.19, 41.51, 41.26, 42.45, 41.22, 41.75, 40.9, 38.55, 43, 38.28, 36.74, 38.03, 35.92, 39.31, 37.93, 39.96, 35.74, 41.3, 40.29, 35.16, 43.84,
    37.41, 38.39, 35.39, 38.8, 35.85, 38.08, 34.77, 41.57, 39.51, 36.04, 42.87, 36.33, 39.26, 34.81, 35.78,
  ];
  let now = new Date(1997, 9, 3);
  let oneDay = 24 * 3600 * 1000;
  let value = Math.random() * 1000;
  for (var i = 0; i < 1000; i++) {
    data.push(randomData());
  }
  option2 = {
    grid: {
      top: 10,
      bottom: 20,
      left: "30%",
      right: "30%",
    },

    tooltip: {
      trigger: "axis",
      formatter: function (params) {
        params = params[0];
        var date = new Date(params.name);
        // var result=date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear() + " : " + params.value[1];
        return date.getFullYear();
      },
    },
    xAxis: {
      type: "time",
      splitLine: {
        show: false,
      },
      axisLabel: {
        color: "white",
      },
      axisLine: {
        show: false,
      },
      axisTick: {
        show: false,
      },
    },
    yAxis: {
      type: "value",
      boundaryGap: [0, "10%"],
      splitLine: {
        show: false,
      },
      axisLabel: {
        color: "white",
      },
    },
    series: [
      {
        name: "Fake Data",
        type: "line",
        showSymbol: false,
        data: data,
      },
    ],
  };

  // option2 = {
  //   // Make gradient line here
  //   grid: {
  //     top: 10,
  //     bottom: 20,
  //     left: "20%",
  //     right: "20%",
  //   },

  //   title: [],
  //   tooltip: {
  //     trigger: "axis",
  //   },
  //   xAxis: [
  //     {
  //       data: [2019, 2020, 2021, 2022, 2023, 2024],
  //       axisLabel: {
  //         color: "white",
  //       },
  //       axisLine: {
  //         show: false,
  //       },
  //       axisTick: {
  //         show: false,
  //       },
  //     },
  //   ],
  //   yAxis: [
  //     {
  //       splitLine: {
  //         show: false,
  //       },
  //       axisLabel: {
  //         color: "white",
  //       },
  //       lineStyle: {
  //         width: 10, // Adjust this value to create space between data points
  //       },
  //     },
  //   ],
  //   series: [
  //     {
  //       type: "line",
  //       color: "white",
  //       showSymbol: false,
  //       data: data,
  //     },
  //   ],
  // };
  option2 && myChart2.setOption(option2);

  var chartDom4 = document.getElementById("chartId4");
  var myChart4 = echarts.init(chartDom4);
  var option4;

  option4 = {
    color: [
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.blueViolet,
      },
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.cyanBlue,
      },
      {
        type: "linear", // "radial" for radial gradient
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: colorStops.redOrange,
      },
    ],
    grid: {
      top: 0,
      bottom: 0,
      left: "10%",
      right: "10%",
    },
    // tooltip: {
    //   trigger: "item",
    // },
    legend: {
      itemWidth: 10, // Change the width of legend icon
      itemHeight: 8,
      top: "80%",
      textStyle: {
        fontSize: 8,
        color: "white",
      },
    },
    series: [
      {
        name: "Access From",
        type: "pie",
        radius: ["50%", "80%"],
        center: ["50%", "40%"],
        avoidLabelOverlap: false,

        label: {
          position: "inside",
          formatter: " {d}% ",
          color: "white",
          fontSize: 8,
        },

        labelLine: {
          show: false,
        },
        data: [
          { value: 72, name: "Public House" },
          { value: 16, name: "Industrial" },
          { value: 12, name: "Household" },
        ],
      },
    ],
  };
  option4 && myChart4.setOption(option4);
})(window.cwidget ? window.cwidget : cwidget);
