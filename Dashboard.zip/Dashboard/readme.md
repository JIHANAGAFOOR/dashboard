# Folder Structure of Repository

- assets: elements of design System. Contains, colours, fonts, and icons.
- build: Tools used for creating AVEVA Web Widgets. Command line tool will pack the folder into .cwp file.
- libs: Local versions of the commonly used libraries in widgets.
- src: Source file of all the widgets.
- template: Template of the basic card structure with completely responsiveness.
